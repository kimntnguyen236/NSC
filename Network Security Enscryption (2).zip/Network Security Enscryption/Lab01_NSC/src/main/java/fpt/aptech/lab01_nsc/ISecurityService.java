/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fpt.aptech.lab01_nsc;

/**
 *
 * @author BuuBuu
 */
public interface ISecurityService {
    void createKey();
    void dataEncryption();
    void dataDecryption();
    
}
